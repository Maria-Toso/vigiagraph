"""Persistence and external adapters."""

