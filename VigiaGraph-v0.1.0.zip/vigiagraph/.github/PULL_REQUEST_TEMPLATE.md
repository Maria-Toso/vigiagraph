## Problema

Descreva o problema resolvido.

## Solucao

Explique a abordagem e as principais decisoes.

## Validacao

- [ ] Adicionei ou atualizei testes.
- [ ] Executei `ruff check .`.
- [ ] Executei `pytest`.
- [ ] Nao inclui dados pessoais ou financeiros reais.
- [ ] Atualizei a documentacao quando necessario.

## Evidencias

Inclua prints, respostas da API ou resultados de testes quando forem relevantes.

